<?php
    $id_b = $_POST['id_b'];
    $id_u = $_POST['id_u'];
    $comment = $_POST['comment'];
    $rating = $_POST['rating'];
    mysqli_query($connect, "SELECT * FROM `comment`");
    if (mysqli_num_rows($id_u > 0)) {

    }