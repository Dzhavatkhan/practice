<?php
session_start();
require_once 'connect.php';
$login = $_POST['login'];
$password = md5($_POST['password']);
$check_user = mysqli_query($connect, "SELECT * FROM `users` WHERE `login` = '$login' AND `password` = '$password'");
if (mysqli_num_rows($check_user) > 0) {
    $user = mysqli_fetch_assoc($check_user);
    $_SESSION['message'] = 'Выход произведён успешно';
    $_SESSION['user'] = [
        "id" => $user['id'],
        "login" => $user['login'],
        "password" => $user['password'],
        "img" => $user['img'],
        "full_name" => $user['full_name'],
        "status" => $user['status'],
    ];
    header('Location: profile.php');
} else {
    $_SESSION['message'] = 'Неверный логин или пароль';
    header('Location: auth.php');
}
